import * as React from "react";
import { IMegamenuProps } from "./IMegamenuProps";
export default class Megamenu extends React.Component<IMegamenuProps, {}> {
    constructor(props: any);
    render(): JSX.Element;
}
//# sourceMappingURL=Megamenu.d.ts.map