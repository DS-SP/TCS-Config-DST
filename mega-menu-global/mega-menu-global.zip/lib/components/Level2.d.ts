import * as React from "react";
import { ILevel2Props } from "./ILevel2Props";
export default class Level2 extends React.Component<ILevel2Props, {}> {
    constructor(props: any);
    render(): JSX.Element;
}
//# sourceMappingURL=Level2.d.ts.map