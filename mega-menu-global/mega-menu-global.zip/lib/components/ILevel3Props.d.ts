import { Link } from "../extensions/model/Link";
export interface ILevel3Props {
    links: Link[];
}
//# sourceMappingURL=ILevel3Props.d.ts.map