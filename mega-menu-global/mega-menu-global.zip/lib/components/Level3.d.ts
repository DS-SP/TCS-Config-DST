import * as React from "react";
import { ILevel3Props } from "./ILevel3Props";
export default class Level3 extends React.Component<ILevel3Props, {}> {
    constructor(props: any);
    render(): JSX.Element;
}
//# sourceMappingURL=Level3.d.ts.map