import { FlyoutColumn } from "../extensions/model/FlyoutColumn";
export interface ILevel2Props {
    level2Items: FlyoutColumn[];
}
//# sourceMappingURL=ILevel2Props.d.ts.map