import { TopLevelMenu } from "../model/TopLevelMenu";
export declare const sampleData: TopLevelMenu[];
//# sourceMappingURL=MegaMenuSampleData.d.ts.map