import { Link } from './Link';
export declare class FlyoutColumn {
    id: number;
    level1ParentId: number;
    heading?: Link;
    links?: Link[];
    columnNumber?: number;
}
//# sourceMappingURL=FlyoutColumn.d.ts.map