import { FlyoutColumn } from './FlyoutColumn';
export declare class TopLevelMenu {
    id: number;
    text: string;
    columns?: FlyoutColumn[];
    url: string;
}
//# sourceMappingURL=TopLevelMenu.d.ts.map