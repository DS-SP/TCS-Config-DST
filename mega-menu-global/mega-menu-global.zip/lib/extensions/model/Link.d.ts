export declare class Link {
    level2ParentId?: number;
    text: string;
    url?: string;
    openInNewTab?: boolean;
}
//# sourceMappingURL=Link.d.ts.map