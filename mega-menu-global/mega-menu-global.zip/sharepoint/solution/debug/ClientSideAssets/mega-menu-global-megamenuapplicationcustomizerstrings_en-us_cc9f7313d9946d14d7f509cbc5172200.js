define([], function() {
  return {
    "Title": "MegamenuApplicationCustomizer"
  }
});