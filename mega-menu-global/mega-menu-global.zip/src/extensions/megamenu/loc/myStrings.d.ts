declare interface IMegamenuApplicationCustomizerStrings {
  Title: string;
}

declare module 'MegamenuApplicationCustomizerStrings' {
  const strings: IMegamenuApplicationCustomizerStrings;
  export = strings;
}
