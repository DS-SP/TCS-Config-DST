import { FlyoutColumn } from "../extensions/model/FlyoutColumn";
export interface ILevel2Props {
  level2Items: FlyoutColumn[];
}
