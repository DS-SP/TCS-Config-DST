import {TopLevelMenu} from "../extensions/model/TopLevelMenu";
export interface IMegamenuProps {
  topLevelMenuItems: TopLevelMenu[];
}