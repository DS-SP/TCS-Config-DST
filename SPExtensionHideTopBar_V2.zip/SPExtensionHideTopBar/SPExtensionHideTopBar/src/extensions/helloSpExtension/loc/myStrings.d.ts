declare interface IHelloSpExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'HelloSpExtensionApplicationCustomizerStrings' {
  const strings: IHelloSpExtensionApplicationCustomizerStrings;
  export = strings;
}
