import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'HelloSpExtensionApplicationCustomizerStrings';

const LOG_SOURCE: string = 'HelloSpExtensionApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHelloSpExtensionApplicationCustomizerProperties {
  // This is an example; replace with your own property
  testMessage: string;
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class HelloSpExtensionApplicationCustomizer
  extends BaseApplicationCustomizer<IHelloSpExtensionApplicationCustomizerProperties> {

  @override
  public onInit(): Promise<void> {

    let suiteBarNav: HTMLElement = document.getElementById("SuiteNavWrapper") as HTMLElement;
    suiteBarNav.setAttribute("style", "display: none !important");
    let spSiteHeader: HTMLElement = document.getElementById("spSiteHeader") as HTMLElement;
    spSiteHeader.setAttribute("style", "display: none !important");

    return Promise.resolve();
  }
}
