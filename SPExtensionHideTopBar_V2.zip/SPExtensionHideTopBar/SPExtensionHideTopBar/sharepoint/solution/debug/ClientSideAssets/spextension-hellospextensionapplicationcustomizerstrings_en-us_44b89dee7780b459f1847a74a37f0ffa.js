define([], function() {
  return {
    "Title": "HelloSpExtensionApplicationCustomizer"
  }
});