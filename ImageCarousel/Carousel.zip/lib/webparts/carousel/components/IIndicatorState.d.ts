/// <reference types="react" />
export interface IIndicatorState {
    listItems: JSX.Element[];
}
//# sourceMappingURL=IIndicatorState.d.ts.map