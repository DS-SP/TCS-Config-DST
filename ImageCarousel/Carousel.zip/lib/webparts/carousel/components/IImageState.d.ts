export interface IImageState {
}
//# sourceMappingURL=IImageState.d.ts.map