declare const styles: {
    carousel: string;
    container: string;
    carouselWrapper: string;
    carouselItem: string;
    carouselText: string;
    logo: string;
    carouselImage: string;
};
export default styles;
//# sourceMappingURL=Carousel.module.scss.d.ts.map