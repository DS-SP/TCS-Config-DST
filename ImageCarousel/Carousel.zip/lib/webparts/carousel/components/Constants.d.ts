export declare const SITEURL = "https://pfizer.sharepoint.com/sites/DST/";
export declare const LIBRARYNAME = "HomePage_Carousel_Data";
//# sourceMappingURL=Constants.d.ts.map