import { ServiceScope } from '@microsoft/sp-core-library';
export interface ICarouselProps {
    description?: string;
    serviceScope?: ServiceScope;
}
//# sourceMappingURL=ICarouselProps.d.ts.map