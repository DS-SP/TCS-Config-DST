export interface IDataService {
    getImages: (listName?: string) => Promise<any>;
}
//# sourceMappingURL=IDataService.d.ts.map