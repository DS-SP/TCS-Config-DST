export interface ICarouselImage {
    FileRef: string;
}
//# sourceMappingURL=ICarouselImage.d.ts.map