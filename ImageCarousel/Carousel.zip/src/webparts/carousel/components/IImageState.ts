export interface IImageState {}
