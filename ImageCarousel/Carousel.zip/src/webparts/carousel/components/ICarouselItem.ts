export interface ICarouselItem {
  paragraph?: any;
  FileURL: any;
  heading?: any;
  linkText?: any;
  linkURL?: any;
}
