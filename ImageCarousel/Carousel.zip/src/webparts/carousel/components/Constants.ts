export const SITEURL = "https://pfizer.sharepoint.com/sites/DST/";
export const LIBRARYNAME = "HomePage_Carousel_Data";