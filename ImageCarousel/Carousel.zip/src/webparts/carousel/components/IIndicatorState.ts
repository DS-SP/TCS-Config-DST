export interface IIndicatorState {
  listItems: JSX.Element[];
}
