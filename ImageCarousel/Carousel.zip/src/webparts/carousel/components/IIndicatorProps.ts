export interface IIndicatorProps {
  length: number;
  currentIndex: number;
  changeCurrentItemIndex: any;
}
