/* tslint:disable */
require("./Carousel.module.css");
const styles = {
  carousel: 'carousel_7324a1e9',
  container: 'container_7324a1e9',
  carouselWrapper: 'carouselWrapper_7324a1e9',
  carouselItem: 'carouselItem_7324a1e9',
  carouselText: 'carouselText_7324a1e9',
  logo: 'logo_7324a1e9',
  carouselImage: 'carouselImage_7324a1e9'
};

export default styles;
/* tslint:enable */