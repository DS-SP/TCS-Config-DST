declare const styles: {
    workbench: string;
    header: string;
    headerMenu: string;
    headerTitle: string;
    headerPerson: string;
    pageContent: string;
    commandBar: string;
};
export default styles;
//# sourceMappingURL=Workbench.module.scss.d.ts.map