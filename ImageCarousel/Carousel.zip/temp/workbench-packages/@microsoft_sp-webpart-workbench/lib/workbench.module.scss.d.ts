declare const styles: {};
export default styles;
//# sourceMappingURL=workbench.module.scss.d.ts.map